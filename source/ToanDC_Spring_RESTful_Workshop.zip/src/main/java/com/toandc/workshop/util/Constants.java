package com.toandc.workshop.util;

/**
 * Created by toanqri on 4/1/17.
 */
public final class Constants {
    public static final String DATETIME_FORMAT_JSON = "dd/MM/yyyy HH:mm:ss";
    public static final String TIMEZONE_FORMAT_JSON = "GMT+7";
}
